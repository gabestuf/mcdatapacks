# XP = Worldborder datapack

gabestuf's version of this datapack.

### Start

`function worldborder:start` to start
`function worldborder:reset` to reset

### Description

Border grows 1 block for each level. Borders shrink upon losing levels. Meant for multiplayer, might be too hard/slow in single player. Works well enough...

### Version: 1.20.2
